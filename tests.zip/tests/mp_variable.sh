#! /bin/sh
# Modulo de comando.

NAME=`basename $0`
case "$1" in
	informacion)
		echo "$NAME/INFORMACION"
	;;
  
	iniciar)
		echo "$NAME/INICIAR"
	;;
  
	detener)
		echo "$NAME/DETENER"
	;;

	procesar)
		echo "$NAME/PROCESAR"
		! test -f /tmp/shield.mp
	;;

	*)
		echo "$NAME: El parametro '$1' es incorrecto."
esac
 
